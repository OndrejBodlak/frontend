# Rootnutí 2.F — nasazení

Tohle NENÍ statický soubor ke stažení pro hráče — je to server, který
musíš sám nasadit (na VPS, Raspberry Pi doma, cokoliv s Dockerem).

## Spuštění
```bash
docker compose up -d --build
```

Hráči se pak připojí přes `nc <tvoje-IP> 2222` (nebo přes netcat/telnet klienta).

## Jak to funguje (spoiler pro tebe jako admina)
`/usr/local/bin/attendance_check` běží jako SUID root a spouští `system("id")`
BEZ plné cesty k příkazu. Útočník si může do PATH podstrčit vlastní `id`
skript (např. vytvořit `~/id` s `#!/bin/sh\ncat /root/flag.txt` a přidat
aktuální adresář do PATH před systémový) → spuštění `attendance_check`
pak spustí útočníkův skript s právy roota.

## Bezpečnostní poznámka
Tohle je záměrně zranitelný kontejner — nikdy ho nevystavuj bez izolace
(vlastní VPS/kontejner, ne sdílený server), a po skončení CTF ho smaž.
