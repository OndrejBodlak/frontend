#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

// SIMULACE "kontroly pritomnosti v hodine" -- bezne se spousti jako SUID root,
// ale spousti system() s neplne kvalifikovanou cestou k prikazu = klasicka
// PATH hijacking zranitelnost pro privilege escalation.
int main() {
    printf("Kontroluji pritomnost studenta...\n");
    setuid(0); // simulace SUID root behu
    system("id"); // ZRANITELNOST: nepouziva plnou cestu /usr/bin/id
    printf("Kontrola dokoncena.\n");
    return 0;
}
